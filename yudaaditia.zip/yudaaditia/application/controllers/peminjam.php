<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Peminjam extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
        $this->load->model('Model_peminjam');
        if(!$this->session->userdata('username')) {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] = 'Peminjam';

        $data['peminjam'] = $this->Model_peminjam->getAllPeminjam();
        if( $this->input->post('keyword') ) {
            $data['peminjam'] = $this->Model_peminjam->CariPeminjam();
        }
        $this->load->view('templates/header.php', $data);
        $this->load->view('peminjam/index.php', $data);
        $this->load->view('templates/footer.php');
    }

    public function tambah()
    {
        $this->form_validation->set_rules('peminjam', 'Peminjam', 'trim|required');

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Tambah Peminjam';

            $this->load->view('templates/header.php', $data);
            $this->load->view('peminjam/tambah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_peminjam->TambahPeminjam();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('peminjam');
        }
        
    }

    public function ubah($id)
    {
        $this->form_validation->set_rules('peminjam', 'Peminjam', 'trim|required');
        $data['peminjam'] = $this->Model_peminjam->getPeminjamById($id);

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Ubah Peminjam';

            $this->load->view('templates/header.php', $data);
            $this->load->view('peminjam/ubah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_peminjam->Ubahpeminjam();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('peminjam');
        }
        
    }

    public function hapus($id)
    {
        $this->Model_peminjam->hapusPeminjam($id);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('peminjam');
    }
}
