<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dbpeminjam extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
        $this->load->model('Model_dbpeminjam');
        $this->load->model('Model_peminjam');
        if(!$this->session->userdata('username')) {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] = 'Dbpeminjam';
        if ($this->input->post('submit')) {
            $data['keyword'] = $this->input->post('keyword');
        } else {
            $data['keyword'] = null;
        }
        
        $data['dbpeminjam'] = $this->Model_dbpeminjam->getAllDbpeminjam($data['keyword']);
       
        $this->load->view('templates/header.php', $data);
        $this->load->view('dbpeminjam/index.php', $data);
        $this->load->view('templates/footer.php');
    }
    
    public function tambah()
    {
        $data['dbpeminjam'] = $this->Model_dbpeminjam->getAllDbpeminjam();
        $this->form_validation->set_rules('nis', 'Nis', 'trim|required|numeric');
        $this->form_validation->set_rules('nama', 'Nama', 'trim|required');
        $this->form_validation->set_rules('jumlah_peminjam', 'Jumlah_peminjam', 'trim|required');
        $this->form_validation->set_rules('tanggal', 'Tanggal', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('hp', 'Hp', 'trim|required|numeric');
        $this->form_validation->set_rules('alamat', 'Alamat', 'trim|required');


        if($this->form_validation->run() == false ) {
            $data['title'] = 'Tambah Dbpeminjam';

            $this->load->view('templates/header.php', $data);
            $this->load->view('dbpeminjam/tambah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_dbpeminjam->Tambahdbpeminjam();
            redirect('dbpeminjam');
        }
        
    }

    public function ubah($id)
    {
        $data['dbpeminjam'] = $this->Model_dbpeminjam->getDbpeminjamById($id);
        $data['peminjam'] = $this->Model_peminjam->getAllPeminjam();
        $this->form_validation->set_rules('nis', 'Nis', 'trim|required|numeric');
        $this->form_validation->set_rules('nama', 'Nama', 'trim|required');
        $this->form_validation->set_rules('jumlah_peminjam', 'Jumlah_peminjam', 'trim|required');
        $this->form_validation->set_rules('tanggal', 'Tanggal', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('hp', 'Hp', 'trim|required|numeric');
        $this->form_validation->set_rules('alamat', 'Alamat', 'trim|required');


        if($this->form_validation->run() == false ) {
            $data['title'] = 'Ubah Dbpeminjam';

            $this->load->view('templates/header.php', $data);
            $this->load->view('dbpeminjam/ubah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_dbpeminjam->Ubahdbpeminjam();
            $old_image = $data['dbpeminjam']['foto'];
            unlink(FCPATH . 'assets/foto/' . $old_image);
            $this->session->set_flashdata('flash', 'Diubahkan');
            redirect('dbpeminjam');
        }
        
    }

    public function detail($id)
    {
        $data['dbpeminjam'] = $this->Model_dbpeminjam->getDbpeminjamById($id);
       
        $data['title'] = 'Detail Dbpeminjam';
        $this->load->view('templates/header.php', $data);
        $this->load->view('dbpeminjam/detail.php', $data);
        $this->load->view('templates/footer.php');

    }

    public function hapus($id)
    {
        $data['dbpeminjam'] = $this->Model_dbpeminjam->getDbpeminjamById($id);
        $old_image = $data['dbpeminjam']['foto'];
        unlink(FCPATH . 'assets/foto/' . $old_image);
        $this->Model_dbpeminjam->hapusDbpeminjam($id);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('dbpeminjam');
    }
}