<div class="container">
    <h1>SELAMAT DATANG DI PINJOL PASS</h1>
</div>
<style>
    body {
        background-image:url("https://assets-a1.kompasiana.com/items/album/2021/12/18/waspada-pinjol-ilegal-61bd91a417e4ac3d024f0d12.png");
    }
    </style>