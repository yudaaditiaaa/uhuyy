<div class="container">
    <div class="card" style="width: 18rem;">
    <img src="<?= base_url('assets/foto/') . $dbpeminjam['foto']; ?>" class="card-img-top" alt="...">
        <div class="card-body">
            <h5 class="card-title"><?= $dbpeminjam['nis']; ?></h5>
            <p class="card-text"><?= $dbpeminjam['nama']; ?></p>
        </div>
        <ul class="list-group list-group-flush">
            <li class="list-group-item"><?= $dbpeminjam['jumlah_peminjam']; ?></li>
            <li class="list-group-item"><?= $dbpeminjam['tanggal']; ?></li>
            <li class="list-group-item"><?= $dbpeminjam['email']; ?></li>
            <li class="list-group-item"><?= $dbpeminjam['hp']; ?></li>
            <li class="list-group-item"><?= $dbpeminjam['alamat']; ?></li>
        </ul>
        <div class="card-body">
            <a href="<?= base_url('dbpeminjam'); ?>" class="btn btn-primary">Kembali</a>
        </div>
    </div>
</div>

