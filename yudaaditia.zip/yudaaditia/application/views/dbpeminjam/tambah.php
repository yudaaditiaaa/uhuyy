<div class="container">
    <?= form_open_multipart('dbpeminjam/tambah');?>
        <legend>Tambah Data Dbpeminjam</legend>
        <div class="mb-3">
            <label for="nis" class="form-label">NIk</label>
            <input type="text" class="form-control" id="nis" name="nis" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('nis'); ?></div>
        </div>
        <div class="mb-3">
            <label for="formFile" class="form-label">Foto</label>
            <input class="form-control" type="file" id="formFile" name="image" style="width : 500px;" require>
            <div class="form-text text-danger"><?= form_error('image'); ?></div>
        </div>
        <div class="mb-3">
            <label for="nama" class="form-label">Nama Lengkap</label>
            <input type="text" class="form-control" id="nama" name="nama" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('nama'); ?></div>
        </div>
        <div class="mb-3">
            <label for="jumlah_peminjam" class="form-label">Jumlah Pinjam</label>
            <input type="text" class="form-control" id="jumlah_peminjam" name="jumlah_peminjam" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('jumlah_peminjam'); ?></div>
        </div>
        <div class="mb-3">
            <label for="peminjam" class="form-label">Tanggal Pinjam</label>
            <input type="date" class="form-control" id="tanggal" name="tanggal" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('peminjam'); ?></div>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('email'); ?></div>
        </div>
        <div class="mb-3">
            <label for="hp" class="form-label">Hp</label>
            <input type="text" class="form-control" id="hp" name="hp" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('hp'); ?></div>
        </div>
        <div class="mb-3">
            <label for="alamat" class="form-label">Alamat</label>
            <textarea class="form-control" id="alamat" name="alamat" style="width : 500px;"></textarea>
            <div class="form-text text-danger"><?= form_error('alamat'); ?></div>
        </div>
        <input type="submit" value="submit" class="btn btn-primary"></input>
    </form>
</div>
<style>
    body {
        background-color: grey;
    }
    </style>
