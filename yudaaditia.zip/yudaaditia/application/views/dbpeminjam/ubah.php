 <?= form_open_multipart();?>
        <legend>Ubah Data Peminjam</legend>
        <input type="hidden" name="id" value="<?= $dbpeminjam['id']; ?>">
        <div class="mb-3">
            <label for="nis" class="form-label">NIK</label>
            <input type="text" class="form-control" id="nis" name="nis" value="<?= $dbpeminjam['nis']; ?>" style="width : 500px;">
         <div class="container">
      <div class="form-text text-danger"><?= form_error('nis'); ?></div>
        </div>
        <div class="row">
            <div class="col">
              <label for="formFile" class="form-label">Foto</label>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-3">
                <div class="mb-3">
                    <img src="<?= base_url('assets/foto/') . $dbpeminjam['foto']; ?>"  id="formFile" class="img-thumbnail" width="225" height="330">
                    <input class="form-control" type="file" id="formFile" name="image" value="<?= $dbpeminjam['foto']; ?>" style="width : 500px;" require>
                    <div class="form-text text-danger"><?= form_error('image'); ?></div>
                </div>
            </div>
        </div>
        <div class="mb-3">
            <label for="nama" class="form-label">Nama Lengkap</label>
            <input type="text" class="form-control" id="nama" name="nama" value="<?= $dbpeminjam['nama']; ?>" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('nama'); ?></div>
        </div>
        <div class="mb-3">
            <label for="jumlah_peminjam" class="form-label">Jumlah Pinjam</label>
            <input type="text" class="form-control" id="jumlah_peminjam" name="jumlah_peminjam" value="<?= $dbpeminjam['jumlah_peminjam']; ?>" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('jumlah_peminjam'); ?></div>
        </div>
        <div class="mb-3">
            <label for="peminjam" class="form-label">Tanggal Pinjam</label>
            <input type="date" class="form-con trol" id="tanggal" name="tanggal" value="<?= $dbpeminjam['tanggal']; ?>" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('peminjam'); ?></div>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" value="<?= $dbpeminjam['email']; ?>" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('email'); ?></div>
        </div>
        <div class="mb-3">
            <label for="hp" class="form-label">Hp</label>
            <input type="text" class="form-control" id="hp" name="hp" value="<?= $dbpeminjam['hp']; ?>" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('hp'); ?></div>
        </div>
        <div class="mb-3">
            <label for="alamat" class="form-label">Alamat</label>
            <textarea class="form-control" id="alamat" name="alamat" style="width : 500px;"><?= $dbpeminjam['alamat']; ?></textarea>
            <div class="form-text text-danger"><?= form_error('alamat'); ?></div>
        </div>
        <input type="submit" value="submit" class="btn btn-primary"></input>
    </form>
</div>
<style>
    body {
        background-color: grey;
    }
    </style>
