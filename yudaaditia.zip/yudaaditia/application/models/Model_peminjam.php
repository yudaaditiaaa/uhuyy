<?php
class Model_peminjam extends CI_Model 
{
    public function getAllPeminjam()
    {
        return $query = $this->db->get('peminjam')->result_array();
    }

    public function Tambahpeminjam()
    {
        $data = [
            "peminjam" => $this->input->post('peminjam', true)
        ];

        $this->db->insert('peminjam', $data);
    }

    public function Ubahpeminjam()
    {
        $data = [
            "peminjam" => $this->input->post('peminjam', true)
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('peminjam', $data);
    }

    public function hapusPeminjam($id)       
    {
        $this->db->where('id', $id);
        $this->db->delete('peminjam');
    }

    public function getPeminjamById($id)
    {
        return $this->db->get_where('peminjam', ['id' => $id])->row_array();
    }

    public function Caripeminjam()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('jpeminjam', $keyword);
        return $this->db->get('peminjam')->result_array();
    }
}

?>